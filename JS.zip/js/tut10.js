// Functions in Java Script
console.log('Welcome to Tut10');

let i = 1234;
console.log(i);
function ui(name) {

     i  = 9;
     console.log(i)
     return `This is a ${name} ui`;
 }
console.log(ui("Tanish") , i)

// const mygreet = function(name , thanks = 'Thank You') {
//     let msg = (`Happy Birthday ${name} 
//     If life were a sitcom, you’d be the 
//     witty,glamorous friend and I’d be the
//     dorky sidekick. And I don’t mind that 
//     at all. I hope you have a GREAT 
//     birthday ${thanks}.”`)
//     return msg;
// }


// let name = 'Rohan';
// let name2 = 'Aditya';

// let val = mygreet(name );
// console.log(val)

// const myobj = {
//     name : 'Tanish',
//     game : function () {
//         return 'GTA';
//     }
// }
// console.log(myobj.game())

// arr = ['Fruits', 'Vegetable',
// 'Furniture']

// arr.forEach(function(element , index , 
//     array) {
//     console.log(element , index , 
//         array)
// });