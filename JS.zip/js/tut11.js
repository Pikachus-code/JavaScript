console.log("This is tut11");

let a = window.document;

alert('Hello Tanish !');

a = prompt("This will Destroy Your Computer. Type your Name.");

a = confirm("Are You Sure You Want to Delete this Page?")

a = innerHeight;
a = innerWidth;
a = scrollY;
a = location;
a = location.toString();
a = window.history;
// console.log(a)