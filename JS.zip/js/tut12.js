console.log("Welcome to tut 12");

let a = document;
a = document.all;
// a = document.body;
// a = document.forms[1];
// Array.from(a).forEach(function(element) {
//     console.log(element);
// });

a = document.links[0];
console.log(a);
