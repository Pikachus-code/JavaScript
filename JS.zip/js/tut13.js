// Exercise 1

// Creating a Variable Which is a String Containing The Text which is a Valid Link
// Fetch all Links from a Given Page Which Conatins this Text

let a = document.links;
let myText = 'harry';
Array.from(a).forEach(function(element) {
    if (String(element).includes(myText)){
        console.log(element)    
    }
})