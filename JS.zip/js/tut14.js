// Html Element Selector in JS 

console.log("Welcome to tut14");

// 1. Single Line Selector
let element1 = document.getElementById('myFirst');
let element2 = document.getElementById('mySecond');
let element3 = document.getElementById('myThird');
let element4 = document.getElementById('myFourth');
// element = element.className;
// element = element.childNodes;
// element = element.parentNode;
element1.style.color = 'red';
// element2.style.color = 'green';
// element3.style.color = 'blue';
// element4.style.color = 'dark green';
element1.innerText = 'Welcome Tanish.'
element1.innerHTML = '<b>Welcome Tanish</b>';

// console.log(element1.innerHTML);

let sel = document.querySelector('#mySecond');
sel = document.querySelector('.child');
sel.style.color = 'blue'
// console.log(sel);

// 2. Multiple Element Selector

let elems = document.getElementsByClassName('child');
elems = document.getElementsByClassName('container');
elems = document.getElementsByTagName('div');
console.log(elems);

Array.from(elems).forEach(element => {
    console.log(element)
    element.style.color = 'green'
});


// console.log(elems[0].getElementsByClassName('child'));

