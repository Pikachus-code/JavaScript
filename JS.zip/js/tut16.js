// Creating Removing and Replacing the Elements

console.log('Welcome to Tutorial 16 of JS');

let element = document.createElement('li');
let text = document.createTextNode('I am a Text Node');
element.appendChild(text)
// Add A Class Name to the Li Element
element.className = 'childu1';
element.id = 'CreatedLi';
element.setAttribute('title' , 'mytitle');
// element.innerText = 'Hello This is Created By Tanish';
// element.innerHTML = '<b>Hello This is Created By Tanish</b>';

let ul = document.querySelector('ul.this');
ul.appendChild(element);
// console.log(ul);
// console.log(element)

let elem2 = document.createElement('h3');
elem2.id = 'elem2';
elem2.className = 'elem2';
let tNode = document.createTextNode('This is a Created Node for Elem2')
elem2.appendChild(tNode);

element.replaceWith(elem2);     
let myul = document.getElementById('myul');
myul.replaceChild(element, document.getElementById('fui'));
myul.removeChild(document.getElementById('sui'));

let pr = elem2.hasAttribute('div');
// console.log(elem2, pr);


// Quiz..?
// let elem3 = document.createElement('h5');
// elem3.id = 'CodeWithHarry'
// console.log(elem3);