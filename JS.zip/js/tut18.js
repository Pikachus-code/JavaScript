console.log("Welcome to Tut 18")

let btn = document.getElementById('btn');
// btn.addEventListener('click', func1);
// btn.addEventListener('dblclick', func2);
// btn.addEventListener('mousedown', func3);

// function func1(e) {
//     console.log("Thanks", e);
// }

// function func2(e) {
//     console.log("Thanks It's a Double Click", e);
// }

// function func2(e) {
//     console.log("Thanks It's a Double Click", e);
// }

// function func3(e) {
//     console.log("Thanks It's a Mouse Down! ", e);
// }
// document.querySelector('.no').addEventListener('mouseenter',function() {
//     console.log("You have Entered No.")
// })

// document.querySelector('.no').addEventListener('mouseleave',function() {
//     console.log("You have Entered No.")
// })

document.querySelector('.container').addEventListener('mousemove',function(e) {
    console.log(e.offsetX , e.offsetY);
    document.body.style.backgroundColor = `rgb(${e.offsetX},${e.offsetY},255 )`
    console.log("You have Triggered Mouse Move Event!")
})