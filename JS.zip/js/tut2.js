console.time('Your Code Took')
console.log("Hello Console");
console.log(4 + 34);
console.log([2,3,4,6]);
console.log(true);
console.table({harry : 'This', marks : 32});
console.log(34);
console.warn("This is a Warning");
// console.clear();
console.timeEnd('Your Code Took')
console.error('This is an Error')


