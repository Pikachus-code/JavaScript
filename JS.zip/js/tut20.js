// Local & Session Storage in Java Script
console.log('This is Tut 20');

// // Note 
// // 1. Local Storage Remains Even After Closing Browser Window!
// // 2. Session Storage Does Not Remain Even After Closing The Browser Window!

let impArray = ['Books', 'Calculator', 'Pencil']
localStorage.setItem('Name', 'Tanish');
localStorage.setItem('Name2', 'Anish');
// localStorage.setItem('Name3', 'Priyansh');
// localStorage.setItem('Name4', 'Vinkesh');

localStorage.setItem('Things', JSON.stringify(impArray));



// localStorage.clear();
// localStorage.removeItem('Name2'); 
// localStorage.removeItem('Name3'); 

// let name = localStorage.getItem('Name2');
things = JSON.parse(localStorage.getItem('Things'));
console.log(things);

// let impArray = ['Books', 'Calculator', 'Pencil']
// sessionStorage.setItem('sessionName', 'sTanish');
// sessionStorage.setItem('sessionName2', 'sAnish');
// sessionStorage.setItem('Things', JSON.stringify(impArray));

