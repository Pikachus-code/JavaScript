console.log("tut3");
// Variable in JS
// var , let , const
var name = "Tanish";
var channel;
var marks = 32
// channel = 'CodeWithTanish'
console.log(name , channel , marks)

// Ruled for Creating JS Var
/*
1. Cannot start with Numbers
2. Can Start with Numbers , Letters , _
or $
3. Are Case Sensitive
*/
var city = 'Kolkata';
console.log(city);

const ownersName = 'Tanish';
// ownersName = 'Anish'
console.log(ownersName);


{
    let city = 'Mumbai';
    city = 'Manipur';
    console.log(city);
}
console.log(city);

const arr1 = [12,34,56,67,8,4];
arr1.push(45);
console.log(arr1)
