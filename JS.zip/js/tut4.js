// Primitive Data Types

// String
let name = 'Tanish';
console.log("My String is "+ name);
console.log("Data Type is " + (typeof name));

// Numbers
let marks = 34;
console.log("Data Type is " + (typeof marks));

// Boolean
let isDriver = true;
console.log("Data Type is " + (typeof isDriver));

//Null
let nullVar = null;
console.log("Data Type is " + (typeof nullVar));

// Undefined
let undef = undefined;
console.log("Data Type is " + (typeof undef));

// Reference Data Types

// Arrays
let myarr = [1,2,3,4,5, false, 'String'];
console.log("Data Type is " + (typeof myarr));

// Object Literals
let stMarks = {
    Tanish: 90,
    Anish: 95,
    Rohan: 89
}
console.log(typeof stMarks);
function Findname() {
    
}
console.log(typeof Findname);

let date = new Date();
console.log(typeof date);
