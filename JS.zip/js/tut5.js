// Type Converion 
console.log("Welcome to tut5");
let myVar;
myVar = String(32);
// console.log(myVar , typeof(myVar));

let booleanVar = String(true);
// console.log(booleanVar , typeof(booleanVar));

let date = String(new Date());
// console.log(date , typeof(date));

let arr = String([1,2,3,4]);
// console.log(arr.length , typeof(arr));

let i = 32;
// console.log(i.toString());

let str = Number('3232');
str = Number('323d2');
str = Number(false);
// console.log(str , typeof(str));

let number = parseFloat('32.54554');
console.log(number.toFixed(6) , typeof(number));

// Type Coercion

let myStr = Number('323');
let myNum = 343;

console.log(myStr + myNum);