console.log("Welcome to Tut6");

const name = 'Tanish';
const greeting = 'Good Morning';
// console.log(greeting  + " " +  name);

let html;
html = "<h1> This is Heading </h1>" +
       "<p> This is My Para </p>";
html = html.concat(' this', " str2");
console.log(html);
// console.log(html.length);
// console.log(html.toLocaleLowerCase());
// console.log(html.toUpperCase());
// console.log(html);


// console.log(html[19]);

// console.log(html.indexOf('<'));
// console.log(html.lastIndexOf('<'));
// console.log(html.endsWith('str2'));
// console.log(html.includes('is'));
// console.log(html.substring(0,6));
// console.log(html.slice(21));
// console.log(html.split(' <'));
// console.log(html.replace('This', 'it'));

let fruit2 = 'Orange';
let fruit1 = 'Apple';
let myHtml = `Hello ${name}
            <h1> This is Heading </h1>
            <p> You Like ${fruit1} and 
            ${fruit2}
            `;
document.body.innerHTML = myHtml;