// Arrays and Objects in Java Script

console.log("Welcoeme to Tut7");

let marks = [12,32,45,65,76,87];
const fruits = ['Orange', 'Apple', 'Mango'];
const mixed = ['str', 32, [2,3,4]];

const arr = new Array(23,123,32, 'Orange');
// console.log(marks);
// console.log(fruits);
// console.log(mixed);
// console.log(arr);

// console.log(arr.length);
// console.log(Array.isArray());

arr[0] = 'Tanish';
let arrelement = arr[0];
// console.log('element: ', arrelement);
// console.log(arr);

let value = marks.indexOf(12);
// console.log(value);

// Mutating or Modifying Arrays
// marks.push(323);  // At Back
// marks.unshift(21);  // At front
// marks.pop();  // Remove from Last
// marks.shift();  // Remove from front
// marks.splice(1,3);  // Remove by Our Choice
// marks.reverse();  // Reverse the Whole Array
let marks2 = [1,2,3,4];
marks = marks.concat(marks2);  // Concat Means To Add
// console.log(marks);

let myObj = {
    name : 'Tanish',
    channel : 'CodeWithTanish',
    isActive : true,
    marks : [1,2,3,4]
}
console.log(myObj);
console.log(myObj.isActive);