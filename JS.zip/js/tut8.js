// If Else Conditions and Switches in Java Script

console.log("We are in Tut8 of JAVA SCRIPT");

const age = 28;
const vari = 34;
const doesDrive = true;

// if (age!=19){
//     console.log('Age is not 19')
// }
// if(age!==56){
//     console.log('Age is not 56')
// }
// else{
//     console.log('Age is not 19')
// }

// if (typeof vari !== 'undefined'){
//     console.log("Vari is Defined");
// }
// else{
//     console.log("Vari is not Defined")
// }

// if (doesDrive || age>78){
//     console.log("You Can Drive")
// }
// else{
//     console.log("You Cannot Drive")
// }


// console.log(age==45? "Age is 45" : "Age is not 45");

switch (age) {
    case 18:
        console.log("You are 18")
        break;

    case 28:
        console.log("You are 28")
        break;

    case 38:
        console.log("You are 38")
        break;

    default:
        console.log("You are  not 18")
        break;
        
}
