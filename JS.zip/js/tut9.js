// for , While and do while Loops in Java script

console.log("Welcome to Tutorial 9 of Java Sript")

// console.log(1);
// console.log(2);
// console.log(3);

// General Loops : For , While , Do

// let a =32;
// a +=10;
// a++;
// console.log(a)
// for (let i = 0 ; i < 100; i++){
//     console.log(i);
// }

// let j = 0;
// while(j<10){
//     console.log(j+1)
//     j +=1;
// }


// let k = 0;

// do {
//     console.log(k + 1);
//     if (k === 5) {
//         k += 1
//         continue;
//     }

//     k += 1
// } while (k < 10)


let arr = [0,1,2,3,4,5,6,7,8];

arr.forEach(function (element , index , array) {
    console.log(element , index , array)
})


// let obj = {
//     name: "Tanish",
//     age: 19,
//     type: "Dangerous Programmer",
//     os: 'Ubuntu'
// }
// for(let key in obj){
//     console.log(`The ${key} of the Object 
//     is ${obj[key]}`)
// }




console.log('Done')