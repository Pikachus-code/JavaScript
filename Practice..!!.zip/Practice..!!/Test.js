console.log('Hello World')

// -- Incrementing The Variable.. --
// let myVar = 11;
// myVar = myVar + 2
// myVar++
// console.log(myVar)

// -- Decrementing The Variable.. --
// let myVar = 11;
// myVar = myVar - 2
// myVar--
// console.log(myVar)


// -- Remainder Value --
// let remainder = 11 % 2
// console.log(remainder)


// -- Compound Assignment with Augmented Addition -- 
// let a = 12;
// let b = 21;
// let c = 32;

// a += 12;    // (a = a + 12)
// b += 1;     // (b = b + 1)
// c += 18;    // (c = c + 18)
// console.log(a, b, c)


// -- Compound Assignment with Augmented Subtraction -- 
// let a = 12;
// let b = 21;
// let c = 32;

// a -= 12;    // (a = a - 12)
// b -= 1;     // (b = b - 1)
// c -= 18;    // (c = c - 18)
// console.log(a, b, c)


// -- Escape Sequences --
/*
\n = new line
\r = carriage return
\t = tab
\b = backspace
\f = formfeed
\\ = backslash
*/
// let myStr = "myFirstLine\nmySecondLine\nmyThirdLine\tmyFourthLine"
// console.log(myStr)

// Accesing Array Data
// let myArray = ["Tanish", "Priyanshi", "Dev"]
// myArray[2] = "Great"
// console.log(myArray)


// Getting Nested Array Modified
// let myArr = [["Priyanshi", "Tanish", "Dev"], ["Great", "Good", "Better"], ["Study", "Programming", "Talking"]]
// let myData = myArr[0][0]
// myArr[0][2] = "Parth"
// console.log(myArr)

// Manipulating Array with push Adds at the last Item..
// let myArr = ["Tanish", "Priyanshi"]
// myArr.push("Dev")
// console.log(myArr)

// Manipulating Array with pop which removes the last Item..
// let myArr = ["Tanish", "Priyanshi", "Dev", "Yogesh", "Shashank"]
// myArr.pop()
// console.log(myArr)


// Manipulating Array with shift which removes the First Item..
// let myArr = ["Tanish", "Priyanshi", "Dev", "Yogesh", "Shashank"]
// myArr.shift()
// console.log(myArr)


// Manipulating Array with unshift which Adds as the First Item..
// let myArr = ["Tanish", "Priyanshi", "Dev", "Yogesh", "Shashank"]
// myArr.unshift("Govinda")
// console.log(myArr)


// Running a function
// function tanish(){
//     console.log("Heya World.. How are you..?")
// }
// tanish()


// Arguments
// function tanish(a,b){
//     console.log(a-b)
// }
// tanish(10,5)


// function localScope(){
//     myVar = 9
//     console.log(myVar)
// }
// localScope();
// console.log(myVar)

// let outerWear = "Devarsh";
// function dev(){
//     let outerWear = "Tanish"
//     return outerWear
// }
// console.log(dev())
// console.log(outerWear)

// Get Value from return
// function minusSeven(num){
//     return num - 7
// }
// console.log(minusSeven(10))

// undefined value
// let sum = 0
// function addFive(){
//     sum += 5
// }
// addFive()


// Working with If statements..
// function trueOrFalse(wasThatTrue){
//     if (wasThatTrue){
//         return "Its True"
//     }
//     return "It was False"
// }
// console.log(trueOrFalse(true))


// Equal Sign Assignments
// function equal(val){
//     if(val == 12){
//         return "Equal"
//     }
//     return "Not Equal"
// }
// console.log(equal(12))


// Double Equal Sign converts the String into the Number..!! Therefor Use Triple Equal Sign..!!
// function equals(a,b){
//     if (a === b){
//         return "Yes, They are Equal"
//     }
//     return "Nope, they aren't"
// }
// console.log(equals(10, "10"))


// Non Equality Operator (!= means as not equal)
// function testNotEqual(val){
//     if(val != 99){
//         return "Not Equal"
//     }
//     return "Equal"
// }
// console.log(testNotEqual(10))


// Non Equality Operator (!== means as not equal and will not convert the parameters)
// function testNotEqual(val){
//     if(val !== 10){
//         return "Not Equal"
//     }
//     return "Equal"
// }
// console.log(testNotEqual("10"))


// Greater than Value
// function greaterThan(val){
//     if (val > 12){
//         return "Yes"
//     }
//     return "No"
// }
// console.log(greaterThan(10))


// Greater than or equal to Value
// function greaterThan(val){
//     if (val >= 12){
//         return "Yes"
//     }
//     return "No"
// }
// console.log(greaterThan(10))


// Less than operator Value
// function greaterThan(val){
//     if (val < 12){
//         return "Yes"
//     }
//     return "No"
// }
// console.log(greaterThan(10))


// Less than or Equal to operator Value
// function greaterThan(val){
//     if (val <= 12){
//         return "Yes"
//     }
//     return "No"
// }
// console.log(greaterThan(13))


// And Operator
// function andOr(val){
//     if(val <= 12 && val < 9){
//         return "yes"
//     }
//     return "no"
// }
// console.log(andOr(10))


// Or Operator
// function orOperator(val){
//     if(val > 20 || val < 20){
//         return 'yes'
//     }
//     return "No"
// }
// console.log(orOperator(15))


// Else Statements
// function elseIf(val){
//     if(val > 12){
//         return "Yes"
//     }
//     else{
//         return "No"
//     }
// }
// console.log(elseIf(20))



// Else/If Statements
// function elseIf(val){
//     if(val > 21){
//         return "greater than 12"
//     }
//     else if(val >= 20){
//         return "greater than 20"
//     }
//     else{
//         return "No"
//     }
// }
// console.log(elseIf(18))



// Golf Code
// let names = ["Hole-in-one", "Eagle", "Birdie", "Par", "Bogey", "Double Bogey", "Go Home"]
// function golfScore(par, strokes){
//     if(strokes == 1){
//         return names[0]
//     }
//     else if(strokes <= par - 2){
//         return names[1]
//     }
//     else if(strokes == par - 1){
//         return names[2]
//     }
//     else if(strokes == par){
//         return names[3]
//     }
//     else if(strokes == par + 1){
//         return names[4]
//     }
//     else if(strokes == par + 2){
//         return names[5]
//     }
//     else if(strokes >= par + 3){
//         return names[6]
//     }
//     else{
//         return "Change Me"
//     }
// }
// console.log(golfScore(5,1))



// Switch and default Statements
// function caseInSwitch(val){
//     let answers = ""
//     switch (val) {
//         case "a":
//             answers = "apple"
//             break;
//         case "b":
//             answers = "birdie"
//             break;
//         case "c":
//             answers = "cat"
//             break;
//         case "d":
//             answers = "dog"
//             break;
//         default:
//             answers = "Not from Case"
//             break;
//     }   return answers
// }
// console.log(caseInSwitch("a"))



// Same cases
// function switchStatement(val){
//     let answer = ""
//     switch (val) {
//         case 1:
//         case 2:
//         case 3:
//             answer = "Low"
//             break;
//         case 4:
//         case 5:
//         case 6:
//             answer = "Mid"
//             break;
//         case 7:
//         case 8:
//         case 9:
//             answer = "High"
//             break;
//         default:
//             answer = "Not your Cup of Tea"
//             break;
//     }
//     return answer
// }
// console.log(switchStatement(10))


// Build Objects
// let building = {
//     "name": "shakti",
//     "levels": 10,
//     "located": "Mumbai",
//     "Cooperating": true
// }
// console.log(building)


// Accessing Objects by Dots
// let building = {
//     "name": "shakti",
//     "levels": 10,
//     "located": "Mumbai",
//     "Cooperating": true
// }

// let namess = building.name
// let levelss = building.levels
// console.log(namess)
// console.log(levelss)


// Accessing Objects by Brackets
// let building = {
//     "name": "shakti",
//     "levels": 10,
//     "located": "Mumbai",
//     "Cooperating": true
// }

// let namess = building["name"]
// let location = building["located"]
// console.log(namess)
// console.log(location)



// Accessing Objects by Variables
// let building = {
//     10: "shakti",
//     12: 10,
//     16: "Mumbai",
//     18: true
// }

// let namess = 16
// let location = building[namess]
// console.log(location)


// Updating Object Properties
// let building = {
//     "name": "shakti",
//     "levels": 10,
//     "located": "Mumbai",
//     "Cooperating": true
// }
// console.log(building)
// building.name = "maitri"
// building.levels = 12
// building.located = "Delhi"
// building.Cooperating = false
// console.log(building)


// Add new Properties to Object
// let building = {
//     "name": "shakti",
//     "levels": 10,
//     "located": "Mumbai",
//     "Cooperating": true
// }
// console.log(building)
// building.members = 60
// console.log(building)


// Delete an Property to an Object
// let building = {
//     "name": "shakti",
//     "levels": 10,
//     "located": "Mumbai",
//     "Cooperating": true
// }
// console.log(building)
// delete building.levels
// console.log(building)


// Objects for Lookups
// function phoneticLookup(val) {
//     let result = ""

//     let lookup = {
//         "alpha": "adams",
//         "bravo": "Boston",
//         "charlie": "Chicago",
//         "delta": "Denver",
//         "echo": "Easy",
//         "foxtrot": "Frank"
//     }
//     result = lookup[val]
//     return result
// }
// console.log(phoneticLookup("charlie"));



// Testing Objects for properties
// let myObj = {
//     gift: "Key Chain",
//     pet: "Sheru",
//     bday: "Dev"
// }

// function checkObj(checkProp){
//     if(myObj.hasOwnProperty(checkProp)){
//         return myObj[checkProp]
//     }
//     else{
//         return `No ${checkProp} found`
//     }
// }
// console.log(checkObj("bdays"));


// Nested Objects
// let myStorage = {
//     "car" :{
//         "inside":{
//             "glove box": "maps",
//             "passenger seat":"crumbs"
//         },
//         "outside":{
//             "truck":"jack"
//         }
//     }
// }
// let gloveBoxContent = myStorage.car.inside
// console.log(gloveBoxContent)


// While Loops
// let myArray = []
// let i = 0;
// while(i < 5){
//     myArray.push(i)
//     i++
// }
// console.log(myArray)


// For loops
// let ourArray = []
// for(let i = 12; i > 10; i++ ){
//     ourArray.push(i)
// }
// console.log(ourArray)


// Iterating Odd Numbers
// let myArray = [];
// for(let i = 0; i < 10; i += 2){
//     myArray.push(i)
// }
// console.log(myArray)


// Iterating For Loops backwards
// let myArray = []
// for(let i = 10; i > -1; i-= 2){
//     myArray.push(i)
// }
// console.log(myArray)



// Iterate through an Array with a for loop
// let myArr = [2,3,4,5]
// let total = 0
// for(let i = 0; i < myArr.length; i++){
//     total += myArr[i]
// }
// console.log(total)


// Nesting For Loops
// function multiplyAll(arr){
//     let product = 1
//     for(let i = 0; i < arr.length; i++){
//         for(let j = 0; j < arr[i].length; j++){
//             product *= arr[i][j]
//         }
//     }
//     return product
// }
// let product = multiplyAll([[1,2],[3,4],[5,6,7]])
// console.log(product)


// Do...While Loops
// let myArray = []
// let i = 10

// do{
//     myArray.push(i)
//     i++
// }while(i < 5)
// console.log(i)


// Do...While Loops
// let ourArray = []
// let i = 10
// do{
//     ourArray.push(i)
//     i++
// }while (i < 22) 
// console.log(ourArray, i)


// Profile Lookup
// let contacts = [
//     {
//         "firstName": "Akira",
//         "lastName": "Laine",
//         "number": "9876786756",
//         'likes': ["Pizza", "Coding", "Brownie Points"]
//     },
//     {
//         "firstName": "Harry",
//         "lastName": "Potter",
//         "number": "9223867361",
//         'likes': ["Hogwarts", "Magic", "Hargrid"]
//     },
//     {
//         "firstName": "Tanish",
//         "lastName": "Nahar",
//         "number": "9773700555",
//         'likes': ["Programming", "TT", "Lyrical"]
//     },
//     {
//         "firstName": "Krish",
//         "lastName": "Shah",
//         "number": "5454878765",
//         'likes': ["Fly", "Karate"]
//     }
// ]

// function lookUpProfile(name,prop){
//     for(let i = 0; i < contacts.length; i++){
//         if(contacts[i].firstName === name){
//             return contacts[i][prop] || "No such Property"
//         }
//     }
//     return "No Such Contact"
// }

// let data = lookUpProfile("Harry", "lastName")
// console.log(data)


// myExample
// let Students = [
//     {
//         "firstName": "Tanish",
//         "class": "FYBCom",
//         "div": "E",
//         "strength": "145"
//     },
//     {
//         "firstName": "Shashank",
//         "class": "SYBCom",
//         "div": "A",
//         "strength": "120"
//     },
//     {
//         "firstName": "Devarsh",
//         "class": "TYBCom",
//         "div": "F",
//         "strength": "156"
//     }
// ]

// function lookUpProfile(name, classes){
//     for(let i = 0; i < Students.length; i++){
//         if(Students[i].firstName === name){
//             return Students[i][classes] || "No such name"
//         }  return Students[i][classes] || "No such class"
//     }return "No such Student"
// }

// let data = lookUpProfile("Shashank","strength")
// console.log(data)


// Random Fractions and Whole Number
// function randomFraction(){
//     return Math.random()
// }
// console.log(randomFraction())


// Generate Random Whole Numbers
// function randomWholeNum(){
//     return Math.floor(Math.random() * 60)
// }
// console.log(randomWholeNum())


// Generate random whole Numbers within a range
// function randomRange(myMin, myMax){
//     return Math.floor(Math.random() * (myMax - myMin)) + 1
// }
// let myRandom = randomRange(5, 15)
// console.log(myRandom)


// Use parseInt Function
// function parseIntFunc(str){
//     return parseInt(str)
// }
// console.log(parseIntFunc("89"))


// Use the parseInt function with a Radix
// function parseIntFunc(str){
//     return parseInt(str,2)
// }
// console.log(parseIntFunc("10011")) 


// use the ternary operator
// function checkEqual(a,b){
//     return a===b ? true : false
// }
// console.log(checkEqual(1,1))


// Using nested ternary Operator
// function checkSign(num){
//     return num > 0 ? "Positive" : num < 0 ? "Negative" : "Zero"
// }
// console.log(checkSign(-10))


// Arrow Functions with Parameters
// const myConcat = (arr1, arr2) => arr1.concat(arr2)
// console.log(myConcat([1,2],[3,4,5]))


// Arrow Functions with Parameters and Concatenation
// const mixVegetable = (sabji, bohotSariSabji) => sabji.concat(bohotSariSabji)
// console.log(mixVegetable(["Cabbage","ShimlaMicrch"],["dhaniya", "Cucumber", "Tomato","Mirchi"]))


// Default Parameters
// const increment = (function () {
//     return function increment(number, value = 1){
//         return number + value
//     }
// })()
// console.log(increment(5,2))
// console.log(increment(5))



// The Rest Operator
// const sum = (function(){
//     return function sum(...args){
//         return args.reduce((a,b) => a + b, 0)
//     }
// })()
// console.log(sum(1,2,3))


// The Rest Operator
// const multiplyAll = (function() {
//     return function multiplyAll(...multiplying){
//         return multiplying.reduce((a,b,c) => a*b*c)
//     }
// })()
// console.log(multiplyAll(2,3,4))


// Spread Operator
// const month = ["Jan","Feb","Mar","Apr","May"]
// let months;
// (function(){
//     months = [...month]
//     month[0] = "Monday"
// })();
// console.log(months)


// The Spread operator myExample
// const YEAR = ["2020","2021","2022"]
// let year;
// (function(){
//     year = [...YEAR]
//     YEAR[1] = "2023"
// })()
// console.log(year)


// Destructing Assignments
// const temp = {
//     today : {min : 72, max : 21},
//     tomorrow : {min : 56, max : 45}
// }
// function tmrwsTemp(forecast){
//     const {tomorrow : maxofTomorrow} = forecast
//     return maxofTomorrow
// }
// console.log(tmrwsTemp(temp))



// Destructing Assignments myExample
// const KES = {
//     classes : {FYBCom : 150, SYBCom : 190},
//     divStrength : {E : 120, F : 230}
// }

// function studClass(student){
//     const {divStrength : {E : theClass}} = student
//     return theClass
// }
// console.log(studClass(KES))


// Destructing Assignments 
// const [z,x, , y] = [1,2,3,4]
// console.log(z,x,y)

// let a = 12, b = 32;
// (() => {
//     "use strict"
//     [a,b] = [b,a]
// })();
// console.log(a)
// console.log(b)


// Using Destructing Assignment with Rest Operator
// const source = [1,2,3,4,5,6,7]
// function removeFirstTwo(list){
//     const [arr] = list
//     return arr
// }
// const arr = removeFirstTwo(source)
// console.log(arr)
// console.log(source)

// Using Destructing Assignment with Rest Operator myExample
// const names = ["Tanish", "Pikachu", "Armin", "Eren", "Mikasa"]
// function AOT(characters) {
//     const [, ,...arr1] = characters
//     return arr1
// }
// const arr1 = AOT(names)
// console.log(arr1)
// console.log(names)

// Using Destructing Assignment to pass an object as a function's parameters
// const stats = {
//     max : 12,
//     min : 21,
//     median : 22
// }
// const half = (function(){
//     return function half({max,min}){
//         return (max + min) / 2
//     }
// })()
// console.log(stats)
// console.log(half(stats))

// Simple Fields
// const createPerson = (name, age, gender) => ({name, age, gender})
// console.log(createPerson("Pikachu", 18, "Male"))

// 

